"""基础数据模型模块."""

from typing import Any, TypedDict

from pydantic import BaseModel as PydanticBaseModel
from pydantic import ConfigDict, Field, model_validator


class BaseModel(PydanticBaseModel):
    """基础数据模型."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore", frozen=True)


class CommonParams(BaseModel):
    """通用请求参数."""

    # 客户端类型
    ct: int = Field()
    # 版本号
    cv: int = Field()
    v: int | None = Field(default=None)
    # 平台标识
    platform: str | None = Field(default=None)
    # App ID
    tme_app_id: str | None = Field(default=None, alias="tmeAppID")
    # 渠道 ID
    chid: str | None = Field(default=None)
    # 通用账号标识
    uin: int | None = Field(default=None)
    # [Web/Desktop] CSRF Token
    g_tk: int | None = Field(default=None)
    g_tk_new: int | None = Field(default=None, alias="g_tk_new_20200303")
    # [App] 核心登录态 & QQ互联
    qq: str | None = Field(default=None)
    authst: str | None = Field(default=None)
    tme_login_type: int | None = Field(default=None, alias="tmeLoginType")
    # [App] Android 核心指纹
    qimei: str | None = Field(default=None, alias="QIMEI")
    qimei36: str | None = Field(default=None, alias="QIMEI36")
    # [App] 硬件标识
    open_udid: str | None = Field(default=None, alias="OpenUDID")
    open_udid2: str | None = Field(default=None, alias="OpenUDID2")
    udid: str | None = Field(default=None)
    aid: str | None = Field(default=None)
    guid: str | None = Field(default=None)
    uid: str | None = Field(default=None)
    sid: str | None = Field(default=None)
    os_ver: str | None = Field(default=None)
    phonetype: str | None = Field(default=None)
    devicelevel: str | None = Field(default=None)
    newdevicelevel: str | None = Field(default=None)
    rom: str | None = Field(default=None)
    format: str | None = Field(default=None)
    in_charset: str | None = Field(default=None, alias="inCharset")
    out_charset: str | None = Field(default=None, alias="outCharset")
    # [Web] 通知开关
    notice: int | None = Field(default=None)
    # [Web] 新设备码开关
    need_new_code: int | None = Field(default=None)


class Credential(BaseModel):
    """凭据类.

    Attributes:
        openid:        OpenID
        refresh_token: RefreshToken
        access_token:  AccessToken
        expired_at:    到期时间
        musicid:       QQMusicID
        musickey:      QQMusicKey
        unionid:       UnionID
        str_musicid:   QQMusicID
        refresh_key:   RefreshKey
        login_type:    登录类型
    """

    openid: str = ""
    refresh_token: str = ""
    access_token: str = ""
    expired_at: int = 0
    musicid: int = 0
    musickey: str = ""
    unionid: str = ""
    str_musicid: str = ""
    refresh_key: str = ""
    musickey_create_time: int = Field(default=0, alias="musickeyCreateTime")
    key_expires_in: int = Field(default=0, alias="keyExpiresIn")
    first_login: int = Field(default=0)
    bind_account_type: int = Field(default=0, alias="bindAccountType")
    need_refresh_key_in: int = Field(default=0, alias="needRefreshKeyIn")
    encrypt_uin: str = Field(default="", alias="encryptUin")
    login_type: int = Field(default=0, alias="loginType")

    @model_validator(mode="before")
    @classmethod
    def _infer_login_type(cls, data: Any) -> Any:
        """在缺省时根据 musickey 推断登录类型."""
        if not isinstance(data, dict):
            return data

        if "loginType" in data or "login_type" in data:
            return data

        musickey = data.get("musickey")
        if not musickey:
            return data

        inferred_login_type = 1 if isinstance(musickey, str) and musickey.startswith("W_X") else 2
        return {**data, "loginType": inferred_login_type}

    def is_expired(self) -> bool:
        """检查凭据是否过期."""
        import time

        current_time = int(time.time())
        return current_time >= self.musickey_create_time + self.key_expires_in


class RequestItem(TypedDict):
    """请求项."""

    module: str
    method: str
    param: dict[str, Any] | dict[int, Any]
    preserve_bool: bool


class Response(BaseModel):
    """API 响应基类."""

    @model_validator(mode="before")
    @classmethod
    def _extract_jsonpath_fields(cls, data: Any) -> Any:
        if not isinstance(data, dict):
            return data

        processed_data = data.copy()

        for field_name, field_info in cls.model_fields.items():
            extra = field_info.json_schema_extra

            if isinstance(extra, dict) and "jsonpath" in extra:
                jsonpath_expr_str = str(extra["jsonpath"])
                target_key = field_info.alias or field_name

                from ..utils import parse_jsonpath

                jsonpath_expr = parse_jsonpath(jsonpath_expr_str)
                matches = jsonpath_expr.find(data)

                if matches:
                    values = [match.value for match in matches]
                    if "[*]" in jsonpath_expr_str:
                        # 通配符路径表示提取条目列表, 即使仅命中一条也保持列表,
                        # 兼容上游在仅有一条数据时直接返回对象而非数组的行为.
                        processed_data[target_key] = values
                    elif len(values) == 1:
                        processed_data[target_key] = values[0]
                    else:
                        processed_data[target_key] = values

        return processed_data
